# Example Vault Audit / 示例审计报告
Critical: Unauthorized upgrade
High: Reentrancy
