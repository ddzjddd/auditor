# UUPSUpgradeable / 升级代理模式
English: Protect _authorizeUpgrade with onlyOwner.
中文：必须用 onlyOwner 限制 _authorizeUpgrade，防止任意升级。
