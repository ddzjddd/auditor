# Ownable / 所有权模式
English: onlyOwner modifier restricts sensitive functions.
中文：onlyOwner 修饰符限制敏感函数仅所有者可执行。
