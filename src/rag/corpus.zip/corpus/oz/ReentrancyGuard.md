# ReentrancyGuard / 重入保护
English: Use nonReentrant modifier to prevent nested calls.
中文：使用 nonReentrant 修饰符防止函数被重复进入。
