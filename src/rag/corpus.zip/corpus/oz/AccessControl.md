# AccessControl / 角色控制
English: Manage roles with hasRole and grantRole.
中文：用 hasRole/grantRole 实现细粒度权限控制。
