# ERC20 Issues / 常见问题
1. approve竞态
2. 返回值缺失
